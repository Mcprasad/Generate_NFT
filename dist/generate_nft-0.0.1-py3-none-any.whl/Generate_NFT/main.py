import generate_art

generate_art.generate('scene.jpeg','', 50, 2048, 2048)