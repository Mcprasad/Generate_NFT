import generate_art

generate_art.generate('filename.jpg','', 25, 1920, 1920)

