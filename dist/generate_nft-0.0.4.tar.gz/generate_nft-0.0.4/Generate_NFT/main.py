import generate_art

experiment_name = "mountains"
generate_art.generate('scene.jpeg','', 25, 1920, 1920, experiment_name)

